/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : zls

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2019-03-15 23:22:07
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for dept
-- ----------------------------
DROP TABLE IF EXISTS `dept`;
CREATE TABLE `dept` (
  `dept_id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_no` int(11) NOT NULL DEFAULT '0' COMMENT '部门序号',
  `dept_name` varchar(255) NOT NULL COMMENT '部门名称',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`dept_id`),
  UNIQUE KEY `UK_AREA` (`dept_no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dept
-- ----------------------------
INSERT INTO `dept` VALUES ('1', '1', '业务运营', '2019-01-16 03:50:40');
INSERT INTO `dept` VALUES ('2', '2', '技术支持', '2019-01-16 03:50:11');
INSERT INTO `dept` VALUES ('3', '3', '运维部', '2019-01-16 03:50:26');

-- ----------------------------
-- Table structure for zls_item_area
-- ----------------------------
DROP TABLE IF EXISTS `zls_item_area`;
CREATE TABLE `zls_item_area` (
  `area_name` char(80) DEFAULT NULL COMMENT '地区名称',
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `listpid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '列表显示时相关父对象数据ID',
  `listsetid` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '列表显示时相关对象',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='地区';

-- ----------------------------
-- Records of zls_item_area
-- ----------------------------
INSERT INTO `zls_item_area` VALUES ('天天', '1', '0', '0');
INSERT INTO `zls_item_area` VALUES ('东城区', '2', '1', '3');

-- ----------------------------
-- Table structure for zls_item_education
-- ----------------------------
DROP TABLE IF EXISTS `zls_item_education`;
CREATE TABLE `zls_item_education` (
  `subject` char(80) DEFAULT NULL COMMENT '学历',
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='学历';

-- ----------------------------
-- Records of zls_item_education
-- ----------------------------
INSERT INTO `zls_item_education` VALUES ('本科', '1');

-- ----------------------------
-- Table structure for zls_item_follow
-- ----------------------------
DROP TABLE IF EXISTS `zls_item_follow`;
CREATE TABLE `zls_item_follow` (
  `touserid` mediumint(9) NOT NULL DEFAULT '0' COMMENT '被关注者',
  `fromuserid` mediumint(9) NOT NULL DEFAULT '0' COMMENT '发起关注者',
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='关注';

-- ----------------------------
-- Records of zls_item_follow
-- ----------------------------
INSERT INTO `zls_item_follow` VALUES ('9', '1', '1');
INSERT INTO `zls_item_follow` VALUES ('9', '2', '2');
INSERT INTO `zls_item_follow` VALUES ('9', '3', '3');
INSERT INTO `zls_item_follow` VALUES ('9', '5', '4');
INSERT INTO `zls_item_follow` VALUES ('9', '6', '5');
INSERT INTO `zls_item_follow` VALUES ('9', '17', '6');

-- ----------------------------
-- Table structure for zls_item_grade
-- ----------------------------
DROP TABLE IF EXISTS `zls_item_grade`;
CREATE TABLE `zls_item_grade` (
  `subject` char(80) DEFAULT NULL COMMENT '年级名称',
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='年级';

-- ----------------------------
-- Records of zls_item_grade
-- ----------------------------
INSERT INTO `zls_item_grade` VALUES ('小学', '1');
INSERT INTO `zls_item_grade` VALUES ('初中', '2');
INSERT INTO `zls_item_grade` VALUES ('高中', '3');

-- ----------------------------
-- Table structure for zls_item_menu
-- ----------------------------
DROP TABLE IF EXISTS `zls_item_menu`;
CREATE TABLE `zls_item_menu` (
  `action` char(80) DEFAULT NULL COMMENT '后台文件名',
  `pertable` char(80) DEFAULT NULL COMMENT '数据表中间部分',
  `operation` char(80) DEFAULT NULL COMMENT '数据表后缀/操作',
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `subject` char(80) DEFAULT NULL COMMENT '菜单名称',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否激活',
  `flag` tinyint(4) NOT NULL DEFAULT '99' COMMENT '排序',
  `edit_1` mediumint(9) NOT NULL DEFAULT '0' COMMENT '上级菜单',
  `ico` char(80) DEFAULT NULL COMMENT '标示ico',
  `other` char(80) NOT NULL DEFAULT '&' COMMENT '链接其他部分',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8 COMMENT='系统后台菜单';

-- ----------------------------
-- Records of zls_item_menu
-- ----------------------------
INSERT INTO `zls_item_menu` VALUES ('list', 'user', 'user', '1', '用户', '1', '102', '0', '', '');
INSERT INTO `zls_item_menu` VALUES ('list', 'user', 'user', '2', '用户管理', '1', '102', '1', 'style/msg3.gif', '');
INSERT INTO `zls_item_menu` VALUES ('user', '', 'password', '3', '初始化用户密码', '1', '102', '1', 'style/password_ico.gif', '&auth=admin');
INSERT INTO `zls_item_menu` VALUES ('list', 'user', 'modify', '4', '用户修改姓名', '1', '102', '1', 'style/pencil.gif', '');
INSERT INTO `zls_item_menu` VALUES ('list', 'user', 'modify', '5', '用户修改邮箱', '1', '102', '1', 'style/modify_ico.gif', '');
INSERT INTO `zls_item_menu` VALUES ('list', 'user', 'inviteemail', '6', '用户邀请邮箱', '1', '102', '1', 'style/grouptwo.gif', '');
INSERT INTO `zls_item_menu` VALUES ('class', 'user', 'group', '7', '用户组织结构', '1', '102', '1', 'style/msg028.gif', '');
INSERT INTO `zls_item_menu` VALUES ('excel', 'web', 'attachment', '9', '导入excel', '1', '114', '61', 'style/excel_ico.gif', '');
INSERT INTO `zls_item_menu` VALUES ('list', 'web', 'attachment', '10', '附件管理', '1', '114', '61', 'style/attachment_ico.gif', '');
INSERT INTO `zls_item_menu` VALUES ('list', 'web', 'message', '11', '系统', '1', '108', '0', '', '');
INSERT INTO `zls_item_menu` VALUES ('list', 'web', 'impeach', '12', '意见反馈', '1', '108', '11', 'style/impeach_ico.gif', '');
INSERT INTO `zls_item_menu` VALUES ('list', 'web', 'message', '13', '留言板', '1', '108', '11', 'style/msg9.gif', '');
INSERT INTO `zls_item_menu` VALUES ('user', '', 'password', '14', '修改密码', '1', '109', '11', 'style/password_ico.gif', '');
INSERT INTO `zls_item_menu` VALUES ('dbdict', '', 'db', '15', '数据字典', '1', '115', '62', '', '');
INSERT INTO `zls_item_menu` VALUES ('dbbak', '', '', '16', '数据备份与恢复', '1', '115', '62', '', '');
INSERT INTO `zls_item_menu` VALUES ('user', '', 'postemail', '17', '发送邮件', '1', '114', '61', '', '');
INSERT INTO `zls_item_menu` VALUES ('', '', '', '18', '注销退出', '1', '110', '11', 'style/tourl.gif', '../login.php?action=logout');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'webinfo', '19', '配置', '1', '110', '0', '', '');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'webinfo', '20', '站点信息', '1', '109', '19', '', '');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'parameter', '21', '参数配置', '1', '109', '19', '', '');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'sendmail', '22', '邮件发送配置', '1', '108', '19', '', '');
INSERT INTO `zls_item_menu` VALUES ('itemlist', 'item', 'edit', '23', '后台菜单配置', '1', '115', '62', '', '&id=1');
INSERT INTO `zls_item_menu` VALUES ('sys', '', 'admintpl', '24', '后台样式配置', '1', '109', '19', '', '');
INSERT INTO `zls_item_menu` VALUES ('list', 'user', 'cell', '26', '权限设置', '1', '115', '62', 'style/pthy.gif', '&type=type');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'sethtml', '27', '静态化设置', '1', '113', '61', '', '');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'apilogin', '29', '同步登录授权接口', '1', '109', '19', '', '');
INSERT INTO `zls_item_menu` VALUES ('log', '', '', '30', '后台操作日志', '1', '114', '61', '', '');
INSERT INTO `zls_item_menu` VALUES ('itemcatch', '', 'test', '31', '抓取', '1', '122', '0', '', '');
INSERT INTO `zls_item_menu` VALUES ('itemcatch', '', 'test', '32', '抓取网址测试', '1', '122', '31', '', '');
INSERT INTO `zls_item_menu` VALUES ('list', 'web', 'catchlog', '33', '抓取日志', '1', '122', '31', 'style/catchweb.gif', '');
INSERT INTO `zls_item_menu` VALUES ('class', 'web', 'channel', '34', '频道分类管理', '1', '108', '19', '', '');
INSERT INTO `zls_item_menu` VALUES ('class', 'web', 'sort', '35', '辅助分类字典', '1', '108', '19', '', '');
INSERT INTO `zls_item_menu` VALUES ('help', '', '', '36', '帮助', '1', '124', '0', '', '');
INSERT INTO `zls_item_menu` VALUES ('help', '', 'web', '37', '网站操作说明', '1', '124', '36', 'style/heart_ico.gif', '');
INSERT INTO `zls_item_menu` VALUES ('help', '', 'aboutus', '38', '关于我们', '1', '124', '36', 'style/copyright_ico.gif', '');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'static', '40', '生成静态页', '1', '113', '61', 'style/add.gif', '');
INSERT INTO `zls_item_menu` VALUES ('configure', '', '', '41', '在线升级', '1', '124', '36', '', '');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'scanport', '42', '扫描服务器的端口', '1', '123', '54', '', '&');
INSERT INTO `zls_item_menu` VALUES ('help', '', 'code', '43', '列表标签', '1', '124', '36', '', '&set=list');
INSERT INTO `zls_item_menu` VALUES ('help', '', 'code', '44', '分页标签', '1', '124', '36', '', '&set=page');
INSERT INTO `zls_item_menu` VALUES ('help', '', 'code', '46', '广告', '1', '124', '36', '', '&set=adlist');
INSERT INTO `zls_item_menu` VALUES ('help', '', 'code', '47', '友情链接', '1', '124', '36', '', '&set=friendlink');
INSERT INTO `zls_item_menu` VALUES ('configure', '', '', '48', '更新缓存', '1', '110', '11', '', '&type=cache');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'server', '49', '负载均衡服务器', '1', '109', '19', '', '&');
INSERT INTO `zls_item_menu` VALUES ('', '', '', '50', '网站首页', '1', '108', '11', '', '../');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'markattachment', '52', '附件图片加水印', '1', '114', '61', '', '&');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'shield', '53', '导入替换词汇', '1', '114', '61', '', '&');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'remotedetect', '54', '站长工具', '1', '123', '0', '', '&');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'localdetect', '55', '探测本地服务器', '1', '123', '54', '', '&');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'remotedetect', '56', '探测远程服务器', '1', '123', '54', '', '&');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'domainbaidu', '58', '百度探测', '1', '123', '54', '', '');
INSERT INTO `zls_item_menu` VALUES ('log', '', '', '61', '高级', '1', '113', '0', '', '&');
INSERT INTO `zls_item_menu` VALUES ('help', '', '', '62', '开发者', '1', '115', '0', '', '');
INSERT INTO `zls_item_menu` VALUES ('list', 'web', 'itemset', '63', '构造对象', '1', '116', '62', '', '&');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'seo', '64', '优化设置', '1', '113', '61', '', '&');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'domainalexa', '65', 'alexa探测', '1', '123', '54', '', '&');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'domainwhois', '66', '域名whois探测', '1', '123', '54', '', '&');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'spell', '67', '汉字转拼音', '1', '123', '54', '', '&');
INSERT INTO `zls_item_menu` VALUES ('itemlist', 'item', 'edit', '68', '定时任务', '1', '110', '11', '', '&id=52');
INSERT INTO `zls_item_menu` VALUES ('configure', '', 'groupmax', '69', '去除重复字段', '1', '115', '62', '', '&');

-- ----------------------------
-- Table structure for zls_item_province
-- ----------------------------
DROP TABLE IF EXISTS `zls_item_province`;
CREATE TABLE `zls_item_province` (
  `province_name` char(80) DEFAULT NULL COMMENT '省份名称',
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='省份';

-- ----------------------------
-- Records of zls_item_province
-- ----------------------------
INSERT INTO `zls_item_province` VALUES ('北京', '1');

-- ----------------------------
-- Table structure for zls_item_subject
-- ----------------------------
DROP TABLE IF EXISTS `zls_item_subject`;
CREATE TABLE `zls_item_subject` (
  `subject_id` tinyint(4) NOT NULL DEFAULT '0' COMMENT '科目ID',
  `subject` char(80) DEFAULT NULL COMMENT '科目名称',
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `flag` tinyint(4) NOT NULL DEFAULT '99' COMMENT '排序',
  `edit_grade` char(80) DEFAULT NULL COMMENT '年级',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COMMENT='科目';

-- ----------------------------
-- Records of zls_item_subject
-- ----------------------------
INSERT INTO `zls_item_subject` VALUES ('0', '英语', '1', '99', '2');
INSERT INTO `zls_item_subject` VALUES ('0', '数学', '2', '99', '1');

-- ----------------------------
-- Table structure for zls_item_teacher
-- ----------------------------
DROP TABLE IF EXISTS `zls_item_teacher`;
CREATE TABLE `zls_item_teacher` (
  `teacher` char(255) DEFAULT NULL COMMENT '老师姓名',
  `avatar` varchar(80) DEFAULT NULL COMMENT '真实头像',
  `gender` varchar(255) DEFAULT NULL COMMENT '性别',
  `experience` varchar(255) DEFAULT NULL COMMENT '教学经验',
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `address` char(255) DEFAULT NULL COMMENT '常住地址',
  `university` char(80) DEFAULT NULL COMMENT '毕业学校',
  `education` varchar(255) DEFAULT NULL COMMENT '最高学历',
  `grade` varchar(255) DEFAULT NULL COMMENT '可授年级',
  `taught` varchar(255) DEFAULT NULL COMMENT '可授科目',
  `graduation` varchar(255) DEFAULT NULL COMMENT '毕业状况',
  `auth` varchar(255) DEFAULT NULL COMMENT '老师认证',
  `wechat` char(255) DEFAULT NULL COMMENT '微信',
  `mobile` char(255) DEFAULT NULL COMMENT '手机',
  `price` char(255) DEFAULT NULL COMMENT '价格',
  `style` varchar(2000) DEFAULT NULL COMMENT '教学特点',
  `posttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否激活',
  `flag` tinyint(4) NOT NULL DEFAULT '99' COMMENT '排序',
  `pricetime` varchar(255) DEFAULT NULL COMMENT '价格时长',
  `latitude` char(255) DEFAULT NULL COMMENT '所在纬度',
  `longitude` char(255) DEFAULT NULL COMMENT '所在经度',
  `score` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '评价分数',
  `city` char(255) DEFAULT NULL COMMENT '城市',
  `area` char(255) DEFAULT NULL COMMENT '地区',
  `lastlongin` datetime DEFAULT NULL COMMENT '最后登录时间',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '所属用户的ID',
  `myflag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '注册流程状态',
  `openid` char(255) DEFAULT NULL COMMENT '微信openid',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `gradetaught` varchar(2000) DEFAULT NULL COMMENT '可授学科',
  `teachtime` char(255) DEFAULT NULL COMMENT '可授时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COMMENT='老师';

-- ----------------------------
-- Records of zls_item_teacher
-- ----------------------------
INSERT INTO `zls_item_teacher` VALUES ('李芬华1', '/zls/htmldata/attachment/201903/1547802911212409740.png', '男', '5年以下', '1', '马甸三网络3#', '北京大学', '本科', '小学', '数学,英语,语文', '大学生/毕业生', '已认证', '13811112345', '13811112345', '200', '上课风趣', '2019-03-02 02:50:59', '1', '99', '1小时', '38.928722', '117.393853', '5', '北京', '昌平', '2019-03-02 08:11:20', '1977', '0', null, null, null, null);
INSERT INTO `zls_item_teacher` VALUES ('李芬华2', '/zls/htmldata/attachment/201901/1547802911212409740.png', '女', '5年-10年', '2', '马甸三网络3#', '北京大学', '研究生', '小学,初中', '数学,英语,语文', '专业教师', '已认证', '13811112345', '13811112345', '300', '上课风趣', '2019-02-26 10:01:30', '1', '99', '45分钟', '40.928722', '118.393853', '8', '北京', '昌平', '2019-03-02 08:11:20', '0', '0', null, null, null, null);
INSERT INTO `zls_item_teacher` VALUES ('李芬华3', '/zls/htmldata/attachment/201901/1547802911212409740.png', '男', '5年-10年', '3', '马甸三网络3#', '北京大学', '大专', '小学', '英语', '大学生/毕业生', '已认证', '13811112345', '13811112345', '100', '上课风趣', '2019-02-28 07:11:00', '1', '99', '1小时', '39.028722', '116.193853', '8', '北京', '海淀', '2019-03-02 08:11:20', '0', '0', null, null, null, null);
INSERT INTO `zls_item_teacher` VALUES ('李芬华4', '/zls/htmldata/attachment/201901/1547802911212409740.png', '女', '5年-10年', '4', '马甸三网络3#', '北京大学', '本科', '高中', '英语', '专业教师', '已认证', '13811112345', '13811112345', '300', '上课风趣', '2019-02-28 07:15:52', '1', '99', '1小时', '39.928722', '11.393853', '6', '北京', '通州', '2019-03-02 08:11:20', '0', '0', null, null, null, null);
INSERT INTO `zls_item_teacher` VALUES ('李芬华5', '/zls/htmldata/attachment/201901/1547802911212409740.png', '女', '5年以下', '5', '马甸三网络3#', '北京大学', '大专', '初中', '英语,语文', '大学生/毕业生', '未认证', '13811112345', '13811112345', '300', '上课风趣', '2019-02-28 07:15:02', '1', '99', '1小时', '39.087221', '116.293853', '8', '北京', '通州', '2019-03-02 08:11:20', '0', '0', null, null, null, null);
INSERT INTO `zls_item_teacher` VALUES ('李芬华6', '/zls/htmldata/attachment/201901/1547802911212409740.png', '男', '5年以下', '6', '马甸三网络3#', '北京大学', '本科', '小学', '数学,英语,语文', '大学生/毕业生', '已认证', '13811112345', '13811112345', '200', '上课风趣', '2019-02-28 07:13:49', '1', '99', '1小时', '38.928722', '117.393853', '8', '北京', '丰台', '2019-03-02 08:11:20', '0', '0', null, null, null, null);
INSERT INTO `zls_item_teacher` VALUES ('李芬华7', '/zls/htmldata/attachment/201901/1547802911212409740.png', '女', '5年-10年', '7', '马甸三网络3#', '北京大学', '研究生', '小学,初中', '数学,英语,语文', '专业教师', '已认证', '13811112345', '13811112345', '300', '上课风趣', '2019-02-26 10:01:30', '1', '99', '45分钟', '40.928722', '118.393853', '8', '北京', '昌平', '2019-03-02 08:11:20', '0', '0', null, null, null, null);
INSERT INTO `zls_item_teacher` VALUES ('李芬华8', '/zls/htmldata/attachment/201901/1547802911212409740.png', '男', '5年-10年', '8', '马甸三网络3#', '北京大学', '大专', '小学', '英语', '大学生/毕业生', '已认证', '13811112345', '13811112345', '100', '上课风趣', '2019-02-28 07:11:00', '1', '99', '1小时', '39.028722', '116.193853', '8', '北京', '海淀', '2019-03-02 08:11:20', '0', '0', null, null, null, null);
INSERT INTO `zls_item_teacher` VALUES ('李芬华9', '/zls/htmldata/attachment/201901/1547802911212409740.png', '女', '5年-10年', '9', '马甸三网络3#', '北京大学', '本科', '高中', '数学', '专业教师', '已认证', '13811112345', '13811112345', '300', '上课风趣', '2019-02-28 07:15:52', '1', '99', '1小时', '39.928722', '11.393853', '4', '北京', '通州', '2019-03-15 22:21:13', '0', '3', 'sadf-sdf', null, '高中 数学', null);
INSERT INTO `zls_item_teacher` VALUES ('李芬华10', null, null, null, '10', null, null, null, null, null, null, null, null, null, null, null, '2019-03-05 11:59:52', '1', '99', null, null, null, '0', null, null, null, '0', '1', '15517sdf', null, null, null);
INSERT INTO `zls_item_teacher` VALUES (null, null, null, null, '18', null, null, null, null, null, null, null, null, null, null, null, '2019-03-05 16:12:33', '1', '99', null, null, null, '0', null, null, '2019-03-07 15:16:42', '0', '0', '', null, null, null);
INSERT INTO `zls_item_teacher` VALUES ('aaaaa', null, '男', null, '23', null, null, null, '初中', '物理', null, null, null, null, '0', null, '2019-03-07 17:43:12', '1', '99', '小时', null, null, '0', '北京市', '东城区', '2019-03-08 12:27:32', '0', '3', '', '2019-03-08', '初中 物理', 'aaaaaaa');
INSERT INTO `zls_item_teacher` VALUES ('1111', null, '男', null, '32', null, null, null, null, null, null, null, null, null, null, null, '2019-03-15 22:36:02', '1', '99', null, null, null, '0', '北京市', '东城区', '2019-03-15 23:09:44', '0', '2', 'okm3c4hZqTblyl4-d', '2019-03-15', null, null);
INSERT INTO `zls_item_teacher` VALUES (null, null, null, null, '33', null, null, null, null, null, null, null, null, null, null, null, '2019-03-15 23:10:26', '1', '99', null, null, null, '0', null, null, '2019-03-15 23:12:02', '0', '3', 'okm3c4fdfhZqTblyl4-qeLJXABuMii8', null, null, null);
INSERT INTO `zls_item_teacher` VALUES (null, '/zls/htmldata/attachment/201903/20190315111832426517.jpg', null, null, '34', null, null, null, null, null, null, null, null, null, null, null, '2019-03-15 23:12:30', '1', '99', null, null, null, '0', null, null, '2019-03-15 23:19:58', '0', '2', 'okm3c4hZqTblyl4-qeLJXABuMii8', null, null, null);

-- ----------------------------
-- Table structure for zls_item_teacher_certificate
-- ----------------------------
DROP TABLE IF EXISTS `zls_item_teacher_certificate`;
CREATE TABLE `zls_item_teacher_certificate` (
  `certificate` varchar(80) DEFAULT NULL COMMENT '证件',
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `pid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '编辑时相关父对象数据ID',
  `setid` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '编辑时相关父对象',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='老师相关证件';

-- ----------------------------
-- Records of zls_item_teacher_certificate
-- ----------------------------

-- ----------------------------
-- Table structure for zls_item_teacher_experience
-- ----------------------------
DROP TABLE IF EXISTS `zls_item_teacher_experience`;
CREATE TABLE `zls_item_teacher_experience` (
  `begin` date DEFAULT NULL COMMENT '这里写说明',
  `end` date DEFAULT NULL COMMENT '这里写说明',
  `school` char(80) DEFAULT NULL COMMENT '所教学校',
  `content` varchar(2000) DEFAULT NULL COMMENT '教学内容',
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `subject` char(80) DEFAULT NULL COMMENT '授课科目',
  `pid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '编辑时相关父对象数据ID',
  `setid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '编辑时相关父对象',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='教学经历';

-- ----------------------------
-- Records of zls_item_teacher_experience
-- ----------------------------
INSERT INTO `zls_item_teacher_experience` VALUES ('2014-01-15', '2019-01-09', '北京三中', '新概念英语', '1', '英语', '1', '10');
INSERT INTO `zls_item_teacher_experience` VALUES ('2019-12-24', '2019-02-26', '北京三中', '新概念英语', '2', '英语', '2', '10');
INSERT INTO `zls_item_teacher_experience` VALUES ('2019-02-27', '2019-02-27', '北京三中', '新概念英语', '3', '英语', '3', '10');
INSERT INTO `zls_item_teacher_experience` VALUES ('2019-02-28', '2019-02-28', '北京三中', '新概念英语', '4', '英语', '5', '10');
INSERT INTO `zls_item_teacher_experience` VALUES ('2019-02-28', '2019-02-28', '北京三中', '新概念英语', '5', '英语', '4', '10');

-- ----------------------------
-- Table structure for zls_item_teacher_follow
-- ----------------------------
DROP TABLE IF EXISTS `zls_item_teacher_follow`;
CREATE TABLE `zls_item_teacher_follow` (
  `touserid` mediumint(9) NOT NULL DEFAULT '0' COMMENT '被关注者',
  `fromuserid` mediumint(9) NOT NULL DEFAULT '0' COMMENT '发起关注者',
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='关注';

-- ----------------------------
-- Records of zls_item_teacher_follow
-- ----------------------------
INSERT INTO `zls_item_teacher_follow` VALUES ('9', '1', '1');
INSERT INTO `zls_item_teacher_follow` VALUES ('9', '2', '2');
INSERT INTO `zls_item_teacher_follow` VALUES ('9', '3', '3');
INSERT INTO `zls_item_teacher_follow` VALUES ('9', '5', '4');
INSERT INTO `zls_item_teacher_follow` VALUES ('9', '6', '5');
INSERT INTO `zls_item_teacher_follow` VALUES ('9', '17', '6');
INSERT INTO `zls_item_teacher_follow` VALUES ('9', '8', '7');
INSERT INTO `zls_item_teacher_follow` VALUES ('9', '23', '8');
INSERT INTO `zls_item_teacher_follow` VALUES ('9', '4', '9');
INSERT INTO `zls_item_teacher_follow` VALUES ('9', '7', '10');
INSERT INTO `zls_item_teacher_follow` VALUES ('8', '24', '11');
INSERT INTO `zls_item_teacher_follow` VALUES ('2', '9', '18');
INSERT INTO `zls_item_teacher_follow` VALUES ('1', '9', '19');

-- ----------------------------
-- Table structure for zls_item_teacher_score
-- ----------------------------
DROP TABLE IF EXISTS `zls_item_teacher_score`;
CREATE TABLE `zls_item_teacher_score` (
  `content` varchar(2000) DEFAULT NULL COMMENT '评价内容',
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `listpid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '列表显示时相关父对象数据ID',
  `listsetid` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '列表显示时相关对象',
  `posttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `score` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '评价分数',
  `fromuserid` mediumint(9) NOT NULL DEFAULT '0' COMMENT '评价者id',
  `statementid` mediumint(9) NOT NULL DEFAULT '0' COMMENT '关联的交易id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COMMENT='评价老师';

-- ----------------------------
-- Records of zls_item_teacher_score
-- ----------------------------
INSERT INTO `zls_item_teacher_score` VALUES ('评价内容评价内容contentcontentcontent评价内容评价内容', '1', '9', '10', '2019-03-02 03:04:33', '10', '0', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('评价内容评价内容评价内容评价内容评价内容评价内容', '2', '1', '10', '2019-03-02 03:05:08', '8', '0', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('评价内容评价内容评价内容评价内容评价内容评价内容saasdf<br/><br/>sdafsdfsdf<br/>sadfsadf<br/>撒发送到发送到发送到发送到评价内容', '3', '1', '10', '2019-03-02 03:05:23', '2', '0', '0');
INSERT INTO `zls_item_teacher_score` VALUES (null, '4', '0', '0', '2019-03-15 16:27:13', '4', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES (null, '5', '9', '0', '2019-03-15 16:29:53', '11', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES (null, '6', '9', '0', '2019-03-15 16:33:27', '11', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES (null, '7', '9', '0', '2019-03-15 16:34:48', '11', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES (null, '8', '9', '0', '2019-03-15 16:36:10', '11', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES (null, '9', '9', '0', '2019-03-15 16:39:15', '6', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES (null, '10', '9', '0', '2019-03-15 16:57:39', '6', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES (null, '11', '9', '0', '2019-03-15 17:07:17', '8', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES (null, '12', '9', '0', '2019-03-15 17:07:17', '8', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES (null, '13', '9', '0', '2019-03-15 17:09:05', '8', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES (null, '14', '9', '0', '2019-03-15 17:09:42', '10', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('dsafasdfasdfasdfnois啊大家发哦送快递发货', '15', '9', '0', '2019-03-15 17:09:54', '10', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES (null, '16', '9', '0', '2019-03-15 17:10:29', '0', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES (null, '17', '9', '0', '2019-03-15 17:13:36', '0', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('实施', '18', '9', '0', '2019-03-15 17:15:14', '0', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('啊', '19', '9', '0', '2019-03-15 17:16:43', '2', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('啊啊', '20', '1', '0', '2019-03-15 17:20:21', '2', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('1111', '21', '1', '0', '2019-03-15 17:22:49', '4', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('111', '22', '1', '10', '2019-03-15 17:25:27', '4', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('是', '23', '1', '10', '2019-03-15 17:27:54', '8', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('11', '24', '1', '10', '2019-03-15 17:28:32', '8', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('sss', '25', '1', '10', '2019-03-15 17:29:06', '8', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('1', '26', '1', '10', '2019-03-15 18:32:16', '8', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('a', '27', '1', '10', '2019-03-15 18:35:54', '8', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('1', '28', '1', '10', '2019-03-15 18:38:26', '6', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('1', '29', '1', '10', '2019-03-15 18:40:31', '8', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('11', '30', '1', '10', '2019-03-15 18:42:12', '8', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('2', '31', '1', '10', '2019-03-15 18:42:32', '6', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('1', '32', '1', '10', '2019-03-15 18:45:11', '6', '9', '0');
INSERT INTO `zls_item_teacher_score` VALUES ('11', '33', '1', '10', '2019-03-15 18:46:23', '4', '9', '0');

-- ----------------------------
-- Table structure for zls_item_teacher_statement
-- ----------------------------
DROP TABLE IF EXISTS `zls_item_teacher_statement`;
CREATE TABLE `zls_item_teacher_statement` (
  `amount` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '金额(元)',
  `status` varchar(255) DEFAULT NULL COMMENT '支付状态',
  `type` varchar(255) DEFAULT NULL COMMENT '付款类型',
  `forteacher` mediumint(9) NOT NULL DEFAULT '0' COMMENT '针对老师ID',
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `subject` char(255) DEFAULT NULL COMMENT '服务内容',
  `posttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `start` datetime DEFAULT NULL COMMENT 'vip起始时间',
  `end` datetime DEFAULT NULL COMMENT 'vip终止时间',
  `listpid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '列表显示时相关父对象数据ID',
  `listsetid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '列表显示时相关对象',
  `score` varchar(255) DEFAULT NULL COMMENT '评价',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='交易账单';

-- ----------------------------
-- Records of zls_item_teacher_statement
-- ----------------------------
INSERT INTO `zls_item_teacher_statement` VALUES ('1.00', '1', '1', '1', '1', 'test1', '2019-03-11 11:46:54', '2019-03-11 11:46:29', '2019-03-30 11:46:33', '9', '10', '1');
INSERT INTO `zls_item_teacher_statement` VALUES ('12.00', '1', '2', '2', '2', 'test2', '2019-03-11 11:46:54', '2019-03-11 11:46:29', '2019-03-30 11:46:33', '9', '10', '0');
INSERT INTO `zls_item_teacher_statement` VALUES ('120.00', '1', '3', '1', '3', 'test1', '2019-03-11 11:46:54', '2019-03-11 11:46:29', '2019-03-30 11:46:33', '9', '10', '0');
INSERT INTO `zls_item_teacher_statement` VALUES ('1.00', '1', '1', '1', '4', 'test1', '2019-03-11 11:46:54', '2019-03-11 11:46:29', '2019-03-30 11:46:33', '9', '10', '0');

-- ----------------------------
-- Table structure for zls_item_teacher_university
-- ----------------------------
DROP TABLE IF EXISTS `zls_item_teacher_university`;
CREATE TABLE `zls_item_teacher_university` (
  `university` char(255) DEFAULT NULL COMMENT '毕业院校全称',
  `enrol` date DEFAULT NULL COMMENT '入学时间',
  `graduation` date DEFAULT NULL COMMENT '毕业时间',
  `major` char(255) DEFAULT NULL COMMENT '学习专业',
  `education` varchar(255) DEFAULT NULL COMMENT '学校学历',
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `pid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '编辑时相关父对象数据ID',
  `setid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '编辑时相关父对象',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='老师毕业院校';

-- ----------------------------
-- Records of zls_item_teacher_university
-- ----------------------------
INSERT INTO `zls_item_teacher_university` VALUES ('北京大学', '2008-09-10', '2012-08-22', '外语系', '大专', '1', '1', '10');
INSERT INTO `zls_item_teacher_university` VALUES ('北京大学', '2013-09-19', '2018-02-22', '外语系', '1', '2', '2', '10');
INSERT INTO `zls_item_teacher_university` VALUES ('北京大学', '2019-02-27', '2019-02-27', '外语系', '1', '3', '3', '10');
INSERT INTO `zls_item_teacher_university` VALUES ('北京大学', '2019-02-28', '2019-02-28', '外语系', '1', '4', '5', '10');
INSERT INTO `zls_item_teacher_university` VALUES ('北京大学', '2019-02-28', '2019-02-28', '外语系', '1', '5', '4', '10');
INSERT INTO `zls_item_teacher_university` VALUES ('北京大学', '2002-09-10', '2006-08-22', '外语系', '大专', '6', '1', '10');

-- ----------------------------
-- Table structure for zls_item_university
-- ----------------------------
DROP TABLE IF EXISTS `zls_item_university`;
CREATE TABLE `zls_item_university` (
  `university` char(80) DEFAULT NULL COMMENT '毕业院校全称',
  `enrol_date` date DEFAULT NULL COMMENT '入学时间',
  `graduation_date` date DEFAULT NULL COMMENT '毕业时间',
  `major` char(80) DEFAULT NULL COMMENT '学习专业',
  `edit_education` char(80) DEFAULT NULL COMMENT '学校学历',
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `pid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '编辑时相关父对象数据ID',
  `setid` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT '编辑时相关父对象',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='毕业院校';

-- ----------------------------
-- Records of zls_item_university
-- ----------------------------
INSERT INTO `zls_item_university` VALUES ('北京大学', '2008-09-10', '2012-08-22', '外语系', '1', '1', '1', '10');
INSERT INTO `zls_item_university` VALUES ('北京大学', '2013-09-19', '2018-02-22', '外语系', '1', '2', '2', '10');
INSERT INTO `zls_item_university` VALUES ('北京大学', '2019-02-27', '2019-02-27', '外语系', '1', '3', '3', '10');
INSERT INTO `zls_item_university` VALUES ('北京大学', '2019-02-28', '2019-02-28', '外语系', '1', '4', '5', '10');
INSERT INTO `zls_item_university` VALUES ('北京大学', '2019-02-28', '2019-02-28', '外语系', '1', '5', '4', '10');

-- ----------------------------
-- Table structure for zls_item_user
-- ----------------------------
DROP TABLE IF EXISTS `zls_item_user`;
CREATE TABLE `zls_item_user` (
  `username` char(255) DEFAULT NULL COMMENT '姓名',
  `userpass` char(255) DEFAULT NULL COMMENT '密码',
  `nick` char(255) DEFAULT NULL COMMENT '昵称(唯一)',
  `secname` char(255) DEFAULT NULL COMMENT '个性化域名',
  `email` char(255) DEFAULT NULL COMMENT '登录邮箱',
  `mobile` char(255) DEFAULT NULL COMMENT '登录手机',
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否激活',
  `flag` tinyint(4) NOT NULL DEFAULT '99' COMMENT '排序',
  `avatar` char(255) DEFAULT NULL COMMENT '头像',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '用户类型',
  `groupids` char(255) DEFAULT NULL COMMENT '用户扩展组',
  `usercells` char(255) DEFAULT NULL COMMENT '用户权限',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户';

-- ----------------------------
-- Records of zls_item_user
-- ----------------------------

-- ----------------------------
-- Table structure for zls_msg_action
-- ----------------------------
DROP TABLE IF EXISTS `zls_msg_action`;
CREATE TABLE `zls_msg_action` (
  `actid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `friendid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `type` smallint(6) unsigned NOT NULL DEFAULT '0',
  `message` text NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `note` varchar(255) NOT NULL DEFAULT '0',
  PRIMARY KEY (`actid`),
  KEY `userid` (`userid`),
  KEY `friendid` (`friendid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='站内动作表';

-- ----------------------------
-- Records of zls_msg_action
-- ----------------------------

-- ----------------------------
-- Table structure for zls_msg_thread
-- ----------------------------
DROP TABLE IF EXISTS `zls_msg_thread`;
CREATE TABLE `zls_msg_thread` (
  `threadid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `touid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '接受者（用户id）',
  `fromuid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '发出者（用户id）',
  `threadname` text NOT NULL COMMENT '消息内容',
  `posttime` int(10) NOT NULL DEFAULT '0' COMMENT '发出时间',
  `flag` tinyint(1) NOT NULL DEFAULT '0' COMMENT '标志:0为正常,1发出者删除,2接受者删除',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '消息类型标志:1短消息,2系统消息,3回复,4评论;9请求好友，8同意，7拒绝，6忽略',
  PRIMARY KEY (`threadid`),
  KEY `touid` (`touid`),
  KEY `fromuid` (`fromuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户消息表';

-- ----------------------------
-- Records of zls_msg_thread
-- ----------------------------

-- ----------------------------
-- Table structure for zls_user_cell
-- ----------------------------
DROP TABLE IF EXISTS `zls_user_cell`;
CREATE TABLE `zls_user_cell` (
  `cellid` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '单元ID',
  `parentid` smallint(6) NOT NULL DEFAULT '0',
  `celltitle` varchar(255) NOT NULL COMMENT '单元操控标识',
  `cellname` varchar(63) NOT NULL COMMENT '单元描述',
  `type` tinyint(1) unsigned NOT NULL COMMENT '单元类型,1为dir, 2为page, 3为action=GET,4为action=POST',
  `cellallow` tinyint(1) NOT NULL DEFAULT '0' COMMENT '设为1:附加了限制条件(PAGE/GET/POST)时该条权限才起作用，设为0:无需附件条件就起作用',
  `active` tinyint(1) NOT NULL DEFAULT '0' COMMENT '功能激活与否',
  `flag` tinyint(4) NOT NULL COMMENT '排序',
  PRIMARY KEY (`cellid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='权限功能单元表';

-- ----------------------------
-- Records of zls_user_cell
-- ----------------------------

-- ----------------------------
-- Table structure for zls_user_credit
-- ----------------------------
DROP TABLE IF EXISTS `zls_user_credit`;
CREATE TABLE `zls_user_credit` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `facetrue` tinyint(1) NOT NULL DEFAULT '0' COMMENT '头像:1为真人，0不为真人,-1为提交未审核',
  `card` varchar(20) NOT NULL DEFAULT '0' COMMENT '证件号码',
  `cardtrue` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否真实有效的证件',
  `cardtype` tinyint(1) NOT NULL DEFAULT '0' COMMENT '证件类型：1身份证；2护照；3为驾照；',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户信誉度表';

-- ----------------------------
-- Records of zls_user_credit
-- ----------------------------

-- ----------------------------
-- Table structure for zls_user_extend
-- ----------------------------
DROP TABLE IF EXISTS `zls_user_extend`;
CREATE TABLE `zls_user_extend` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sex` tinyint(2) NOT NULL DEFAULT '0' COMMENT '性别 1:男 2:女 0保密 ',
  `calling` tinyint(4) NOT NULL DEFAULT '0' COMMENT '行业',
  `workyear` tinyint(4) NOT NULL DEFAULT '0' COMMENT '工作年限',
  `height` tinyint(4) NOT NULL DEFAULT '0' COMMENT '身高',
  `school` varchar(255) NOT NULL COMMENT '毕业学校',
  `ddldegree` tinyint(4) NOT NULL DEFAULT '0' COMMENT '学历',
  `salary` tinyint(4) NOT NULL DEFAULT '0' COMMENT '月薪',
  `birth` date NOT NULL DEFAULT '1000-01-01' COMMENT '出生日期',
  `province` varchar(31) NOT NULL COMMENT '所在城市',
  `city` varchar(31) NOT NULL COMMENT '所在县镇',
  `mobphone` varchar(15) DEFAULT NULL COMMENT '常用手机',
  `telphone` varchar(15) DEFAULT NULL COMMENT '常用座机',
  `qq` int(11) DEFAULT NULL COMMENT 'qq',
  `msn` varchar(20) DEFAULT NULL COMMENT 'msn',
  `profile` varchar(255) DEFAULT NULL COMMENT '个人简介',
  `followtheme` varchar(255) DEFAULT NULL COMMENT '关注主题',
  `followclass` varchar(100) DEFAULT NULL COMMENT '关注分类',
  `usertag` varchar(255) DEFAULT NULL COMMENT '用户标签',
  `sign` varchar(255) DEFAULT NULL COMMENT '用户个性签名',
  `content` varchar(255) DEFAULT NULL COMMENT '自我介绍',
  `src` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '来源:1weibo,2qq,3人人,4淘宝,5豆瓣,6开心，7百度，8ucenter',
  `u_id` varchar(32) NOT NULL COMMENT '外站登录授权后的唯一标示',
  `letterset` tinyint(1) NOT NULL DEFAULT '0' COMMENT '私信设置：,0 所有人;1 我收听的人和认证用户;2 我收听的人 ',
  `noticeset` tinyint(1) NOT NULL DEFAULT '0' COMMENT '通知设置',
  `emailset` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 较长时间不登录接收提示',
  `findreemail` varchar(64) NOT NULL COMMENT '重设邮箱',
  `findpsw` varchar(20) NOT NULL COMMENT '矫正码',
  `findpswtime` int(10) unsigned NOT NULL COMMENT '找回密码时间',
  `psw` varchar(20) NOT NULL COMMENT '密码寄存',
  `friendid` mediumint(8) unsigned NOT NULL COMMENT '邀请用户id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户信息扩展表';

-- ----------------------------
-- Records of zls_user_extend
-- ----------------------------

-- ----------------------------
-- Table structure for zls_user_friend
-- ----------------------------
DROP TABLE IF EXISTS `zls_user_friend`;
CREATE TABLE `zls_user_friend` (
  `friendid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '好友id',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户userid',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '好友添加时间',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1为好友，3为黑名单',
  KEY `userid` (`userid`),
  KEY `friendid` (`friendid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户自己的好友表';

-- ----------------------------
-- Records of zls_user_friend
-- ----------------------------

-- ----------------------------
-- Table structure for zls_user_group
-- ----------------------------
DROP TABLE IF EXISTS `zls_user_group`;
CREATE TABLE `zls_user_group` (
  `groupid` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组角色ID',
  `groupname` varchar(63) NOT NULL COMMENT '用户组角色名称',
  `groupcells` varchar(255) NOT NULL COMMENT '单元权限分配',
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '用户组分类(系统 1 、扩展 2)',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '功能激活与否',
  `flag` tinyint(4) NOT NULL COMMENT '用户组显示排序',
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COMMENT='用户组表';

-- ----------------------------
-- Records of zls_user_group
-- ----------------------------
INSERT INTO `zls_user_group` VALUES ('1', '技术部', '', '0', '1', '1', '9');
INSERT INTO `zls_user_group` VALUES ('2', '编辑', '2,1,13,16,14', '0', '1', '1', '4');
INSERT INTO `zls_user_group` VALUES ('3', '管理员', '3,21,18,17,14,16,15,5,13,1,2', '0', '1', '1', '2');
INSERT INTO `zls_user_group` VALUES ('4', '系统管理员', '23,19,4,20,3,21,18,17,14,16,15,5,13,1,2', '0', '1', '1', '1');
INSERT INTO `zls_user_group` VALUES ('5', '高级会员', '', '0', '1', '0', '5');
INSERT INTO `zls_user_group` VALUES ('6', '普通员工', '0', '1', '1', '1', '9');
INSERT INTO `zls_user_group` VALUES ('7', '经理', '0', '1', '1', '1', '1');
INSERT INTO `zls_user_group` VALUES ('8', '部门经理', '0', '0', '1', '1', '3');
INSERT INTO `zls_user_group` VALUES ('9', '注册用户', '0', '0', '1', '1', '5');
INSERT INTO `zls_user_group` VALUES ('10', '授权登录用户', '', '0', '1', '1', '9');
INSERT INTO `zls_user_group` VALUES ('11', '新浪微博用户', '', '10', '1', '1', '9');
INSERT INTO `zls_user_group` VALUES ('12', '腾讯QQ授权用户', '', '10', '1', '1', '9');
INSERT INTO `zls_user_group` VALUES ('13', '人人网授权用户', '', '10', '1', '1', '9');
INSERT INTO `zls_user_group` VALUES ('14', '开心网授权用户', '', '10', '1', '1', '9');
INSERT INTO `zls_user_group` VALUES ('15', '豆瓣授权用户', '', '10', '1', '1', '9');
INSERT INTO `zls_user_group` VALUES ('16', '淘宝授权用户', '', '10', '1', '1', '9');
INSERT INTO `zls_user_group` VALUES ('17', '百度网授权用户', '', '10', '1', '1', '9');
INSERT INTO `zls_user_group` VALUES ('18', 'ucenter授权用户', '', '10', '1', '1', '9');
INSERT INTO `zls_user_group` VALUES ('19', '测试组织结构', '', '0', '1', '0', '0');

-- ----------------------------
-- Table structure for zls_user_inviteemail
-- ----------------------------
DROP TABLE IF EXISTS `zls_user_inviteemail`;
CREATE TABLE `zls_user_inviteemail` (
  `inviteemailid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `inviteemailname` varchar(127) NOT NULL DEFAULT '' COMMENT '邀请邮箱',
  `flag` tinyint(1) NOT NULL DEFAULT '0' COMMENT '排序;同时作为邀请的标识',
  `posttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '邀请发生时间',
  PRIMARY KEY (`inviteemailid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='邀请朋友时的导入邮箱时记录表';

-- ----------------------------
-- Records of zls_user_inviteemail
-- ----------------------------

-- ----------------------------
-- Table structure for zls_user_log
-- ----------------------------
DROP TABLE IF EXISTS `zls_user_log`;
CREATE TABLE `zls_user_log` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '操作时间',
  `text` text COMMENT '内容',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '类型,9为下载',
  `ip` int(10) NOT NULL DEFAULT '0' COMMENT '操作者IP'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户操作日志';

-- ----------------------------
-- Records of zls_user_log
-- ----------------------------

-- ----------------------------
-- Table structure for zls_user_loglogin
-- ----------------------------
DROP TABLE IF EXISTS `zls_user_loglogin`;
CREATE TABLE `zls_user_loglogin` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `loginlogtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录uinxtime时间',
  `loginip` int(10) NOT NULL DEFAULT '0' COMMENT '登录longip'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户登录日志';

-- ----------------------------
-- Records of zls_user_loglogin
-- ----------------------------
INSERT INTO `zls_user_loglogin` VALUES ('1977', '1550195164', '0');
INSERT INTO `zls_user_loglogin` VALUES ('1977', '1551066596', '0');
INSERT INTO `zls_user_loglogin` VALUES ('1977', '1551150829', '2130706433');
INSERT INTO `zls_user_loglogin` VALUES ('1977', '1551425033', '2130706433');
INSERT INTO `zls_user_loglogin` VALUES ('1977', '1551445755', '0');
INSERT INTO `zls_user_loglogin` VALUES ('1977', '1551693508', '2130706433');
INSERT INTO `zls_user_loglogin` VALUES ('1977', '1552119382', '2130706433');
INSERT INTO `zls_user_loglogin` VALUES ('1977', '1552272398', '2130706433');
INSERT INTO `zls_user_loglogin` VALUES ('1977', '1552272413', '2130706433');

-- ----------------------------
-- Table structure for zls_user_logloginerror
-- ----------------------------
DROP TABLE IF EXISTS `zls_user_logloginerror`;
CREATE TABLE `zls_user_logloginerror` (
  `account` varchar(127) NOT NULL COMMENT '登录账户',
  `loginlogtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录时间',
  `loginip` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录longip',
  `count` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '错误次数',
  `error` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '登录错误类型；0为正确，1为密码错误'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of zls_user_logloginerror
-- ----------------------------
INSERT INTO `zls_user_logloginerror` VALUES ('wuseyun', '1550195158', '0', '1', '1');
INSERT INTO `zls_user_logloginerror` VALUES ('wuseyun', '1551066587', '0', '1', '1');

-- ----------------------------
-- Table structure for zls_user_logtime
-- ----------------------------
DROP TABLE IF EXISTS `zls_user_logtime`;
CREATE TABLE `zls_user_logtime` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `dates` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '一年中的第几X(天、月、年)',
  `times` smallint(7) unsigned NOT NULL DEFAULT '0' COMMENT '秒数',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1:day,2:week,3:month;在线时间类别'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='年月日各阶段用户在线时长';

-- ----------------------------
-- Records of zls_user_logtime
-- ----------------------------

-- ----------------------------
-- Table structure for zls_user_member
-- ----------------------------
DROP TABLE IF EXISTS `zls_user_member`;
CREATE TABLE `zls_user_member` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `fromuserid` mediumint(9) NOT NULL DEFAULT '0' COMMENT '发出邀请的userid',
  `regtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `neartime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最近登录时间',
  `modifytime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最近修改时间',
  `logincounts` smallint(5) unsigned NOT NULL DEFAULT '1' COMMENT '登录次数',
  `onlinetimes` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '总共在线时间',
  `friendcount` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '好友数量',
  `invitationcount` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '邀请数量',
  `jifencount` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '积分总数',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户状态扩展表';

-- ----------------------------
-- Records of zls_user_member
-- ----------------------------

-- ----------------------------
-- Table structure for zls_user_modify
-- ----------------------------
DROP TABLE IF EXISTS `zls_user_modify`;
CREATE TABLE `zls_user_modify` (
  `modifyid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) NOT NULL DEFAULT '0' COMMENT '1:姓名2:Email,3:处理过姓名,4:处理过email',
  `modifyname` varchar(255) NOT NULL DEFAULT '0' COMMENT '修改的值',
  `detail` varchar(255) NOT NULL DEFAULT '0' COMMENT '修改理由',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '提交申请的用户ID',
  `time` int(10) NOT NULL DEFAULT '0' COMMENT '提交时间',
  `active` tinyint(1) NOT NULL DEFAULT '0' COMMENT '激活',
  PRIMARY KEY (`modifyid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户需要修改的内容纪录表';

-- ----------------------------
-- Records of zls_user_modify
-- ----------------------------

-- ----------------------------
-- Table structure for zls_user_money
-- ----------------------------
DROP TABLE IF EXISTS `zls_user_money`;
CREATE TABLE `zls_user_money` (
  `moneyid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1为虚拟货币',
  `moneyname` int(11) NOT NULL DEFAULT '0',
  `moneycount` int(11) NOT NULL DEFAULT '0',
  `addtime` int(11) NOT NULL DEFAULT '0',
  `active` tinyint(4) NOT NULL COMMENT '是否启用',
  PRIMARY KEY (`moneyid`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户网站币';

-- ----------------------------
-- Records of zls_user_money
-- ----------------------------

-- ----------------------------
-- Table structure for zls_user_preference
-- ----------------------------
DROP TABLE IF EXISTS `zls_user_preference`;
CREATE TABLE `zls_user_preference` (
  `uid` int(8) NOT NULL COMMENT '与用户表的ID关联',
  `letter` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1所有人；2我收听的人和认证用户；3我收听的人；0未开启',
  `recommend` tinyint(1) NOT NULL DEFAULT '0' COMMENT '推荐通知,0关闭；1开启',
  `activity` tinyint(1) NOT NULL COMMENT '活动通知，0关闭；1开启',
  `application` tinyint(1) NOT NULL COMMENT '应用通知，0关闭；1开启',
  `mail` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0不接受邮件提示；1接受邮件提示'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户偏好';

-- ----------------------------
-- Records of zls_user_preference
-- ----------------------------

-- ----------------------------
-- Table structure for zls_user_score
-- ----------------------------
DROP TABLE IF EXISTS `zls_user_score`;
CREATE TABLE `zls_user_score` (
  `scoreid` mediumint(8) NOT NULL AUTO_INCREMENT COMMENT '积分自增id',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `score` mediumint(8) NOT NULL DEFAULT '0',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '积分类型',
  `scorecount` mediumint(8) NOT NULL DEFAULT '0' COMMENT '积分数',
  `posttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '积分时间',
  `active` tinyint(1) NOT NULL COMMENT '是否有效',
  PRIMARY KEY (`scoreid`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='积分表';

-- ----------------------------
-- Records of zls_user_score
-- ----------------------------

-- ----------------------------
-- Table structure for zls_user_user
-- ----------------------------
DROP TABLE IF EXISTS `zls_user_user`;
CREATE TABLE `zls_user_user` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID 自增',
  `username` varchar(32) NOT NULL COMMENT '姓名',
  `userpass` varchar(32) NOT NULL DEFAULT '' COMMENT 'md5加密过的密码',
  `nick` varchar(32) NOT NULL COMMENT '昵称(需要唯一)用作登录',
  `secname` varchar(32) NOT NULL DEFAULT '0' COMMENT '二级域名后缀(个性化域名例如www.wuseyun.com/wuseyun)',
  `email` varchar(127) NOT NULL DEFAULT '' COMMENT '登录邮箱',
  `mobile` varchar(11) NOT NULL COMMENT '登录手机',
  `avatar` varchar(64) NOT NULL COMMENT '用户头像图网址',
  `active` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否激活',
  `type` smallint(6) NOT NULL DEFAULT '1' COMMENT '用户类型即系统用户组，唯一对应的用户组',
  `groupids` varchar(255) NOT NULL DEFAULT '0' COMMENT '用户所述用户组的扩展，用英文逗号分隔，可以是多个组合，例如：4,13,5，称之为角色',
  `usercells` varchar(255) NOT NULL DEFAULT '0' COMMENT '用户自身权限分配，优先级别最高，对应的权限单元可以是多个组合，例如：4,13,5',
  `flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`userid`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=1978 DEFAULT CHARSET=utf8 COMMENT='用户的基础表';

-- ----------------------------
-- Records of zls_user_user
-- ----------------------------
INSERT INTO `zls_user_user` VALUES ('1', '岳琉', 'e10adc3949ba59abbe56e057f20f883e', '123456', '0', 'test@test.com', '', '', '1', '9', '', '0', '99');
INSERT INTO `zls_user_user` VALUES ('1977', '没有写', 'c759b898a171b4bd678a1abe2ac17687', '王老虎', '0', 'wuseyun', '', '/htmldata/user/0/1977.jpg', '1', '4', '7,4', '0', '-3');

-- ----------------------------
-- Table structure for zls_web_attachment
-- ----------------------------
DROP TABLE IF EXISTS `zls_web_attachment`;
CREATE TABLE `zls_web_attachment` (
  `attachmentid` int(11) NOT NULL AUTO_INCREMENT COMMENT '附件ID',
  `attachmentname` varchar(255) NOT NULL COMMENT '附件名称',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `setid` smallint(6) NOT NULL DEFAULT '0' COMMENT '对象ID',
  `editid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '对象每条数据的ID',
  `path` varchar(255) NOT NULL COMMENT '附件路径',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '附件类型 1:pic,9:excel',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '排序标识',
  `active` tinyint(4) NOT NULL DEFAULT '0' COMMENT '激活与否',
  PRIMARY KEY (`attachmentid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='附件表';

-- ----------------------------
-- Records of zls_web_attachment
-- ----------------------------
INSERT INTO `zls_web_attachment` VALUES ('1', '111.png', '1977', '10', '1', '/mini/htmldata/attachment/201901/1547802911212409740.png', '1', '2019-01-18 09:15:11', '0', '0');
INSERT INTO `zls_web_attachment` VALUES ('2', '111.png', '1977', '10', '1', '/zls/htmldata/attachment/201901/1547802911212409740.png', '1', '2019-01-18 10:24:12', '0', '0');
INSERT INTO `zls_web_attachment` VALUES ('3', 'Desert.jpg', '1977', '10', '1', '/zls/htmldata/attachment/201903/1547802911212409740.png', '1', '2019-03-02 00:08:30', '0', '0');
INSERT INTO `zls_web_attachment` VALUES ('4', 'Desert - 副本.jpg', '1977', '11', '1', '/zls/htmldata/attachment/201903/155148667650650315.jpg', '1', '2019-03-02 00:31:17', '0', '0');
INSERT INTO `zls_web_attachment` VALUES ('5', 'Penguins.jpg', '1977', '11', '2', '/zls/htmldata/attachment/201903/1551486676180345449.jpg', '1', '2019-03-02 00:31:17', '0', '0');
INSERT INTO `zls_web_attachment` VALUES ('6', 'Hydrangeas.jpg', '1977', '11', '3', '/zls/htmldata/attachment/201903/15514866769954665.jpg', '1', '2019-03-02 00:31:17', '0', '0');
INSERT INTO `zls_web_attachment` VALUES ('7', 'Desert.jpg', '1977', '11', '4', '/zls/htmldata/attachment/201903/1551486676557800716.jpg', '1', '2019-03-02 00:31:18', '0', '0');

-- ----------------------------
-- Table structure for zls_web_catchlog
-- ----------------------------
DROP TABLE IF EXISTS `zls_web_catchlog`;
CREATE TABLE `zls_web_catchlog` (
  `catchlogid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `catchlogname` char(255) DEFAULT NULL COMMENT '抓取标题',
  `detail` char(255) DEFAULT NULL COMMENT '详细',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '时间',
  `setid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '对象id',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '类型',
  `active` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1启用0停用',
  `flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`catchlogid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='抓取日志';

-- ----------------------------
-- Records of zls_web_catchlog
-- ----------------------------

-- ----------------------------
-- Table structure for zls_web_channel
-- ----------------------------
DROP TABLE IF EXISTS `zls_web_channel`;
CREATE TABLE `zls_web_channel` (
  `channelid` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `channelname` varchar(30) NOT NULL COMMENT '频道名称',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `type` smallint(6) NOT NULL DEFAULT '0' COMMENT '类型，0为用户定义，1为系统，...',
  `flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '排序',
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '激活与否',
  `url` varchar(80) NOT NULL COMMENT '外部链接',
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  PRIMARY KEY (`channelid`),
  KEY `channelname` (`channelname`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8 COMMENT='系统频道表';

-- ----------------------------
-- Records of zls_web_channel
-- ----------------------------
INSERT INTO `zls_web_channel` VALUES ('22', 'CMS', '0', '1', '1', '1', '', '0');
INSERT INTO `zls_web_channel` VALUES ('33', '资讯', '0', '1', '0', '1', '', '22');
INSERT INTO `zls_web_channel` VALUES ('34', '音视频', '0', '1', '0', '1', '', '22');
INSERT INTO `zls_web_channel` VALUES ('35', '有图有真相', '0', '1', '0', '1', '', '22');
INSERT INTO `zls_web_channel` VALUES ('54', '报道', '0', '1', '0', '1', '', '33');
INSERT INTO `zls_web_channel` VALUES ('77', '在线学院', '0', '1', '0', '1', '', '34');
INSERT INTO `zls_web_channel` VALUES ('90', '作品欣赏', '0', '1', '0', '1', '', '35');
INSERT INTO `zls_web_channel` VALUES ('105', '技术', '0', '1', '0', '1', '', '33');

-- ----------------------------
-- Table structure for zls_web_classlink
-- ----------------------------
DROP TABLE IF EXISTS `zls_web_classlink`;
CREATE TABLE `zls_web_classlink` (
  `sortid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'sortid辅助分类id',
  `linkid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT 'news文章ID',
  `setid` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '对象id',
  KEY `sortid` (`sortid`,`linkid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='辅助ID对应新闻ID';

-- ----------------------------
-- Records of zls_web_classlink
-- ----------------------------

-- ----------------------------
-- Table structure for zls_web_comment
-- ----------------------------
DROP TABLE IF EXISTS `zls_web_comment`;
CREATE TABLE `zls_web_comment` (
  `commentid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `editid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '回复对象的数据的id',
  `userid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '操作用户id',
  `usernick` varchar(32) NOT NULL COMMENT '用户姓名',
  `parentid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '回复评论的父id',
  `posttime` int(10) NOT NULL DEFAULT '0' COMMENT '提交时间',
  `comment` text NOT NULL COMMENT '回复内容',
  `objid` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '回复类型与对象ID',
  `active` tinyint(1) NOT NULL COMMENT '是否公开',
  PRIMARY KEY (`commentid`),
  KEY `editid` (`editid`),
  KEY `parentid` (`parentid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='回复评论表';

-- ----------------------------
-- Records of zls_web_comment
-- ----------------------------

-- ----------------------------
-- Table structure for zls_web_impeach
-- ----------------------------
DROP TABLE IF EXISTS `zls_web_impeach`;
CREATE TABLE `zls_web_impeach` (
  `impeachid` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '用户userid',
  `impeachname` varchar(255) NOT NULL DEFAULT '0' COMMENT '联系方式',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '问题类型',
  `content` text NOT NULL COMMENT '内容',
  `posttime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '提交时间',
  `active` tinyint(1) NOT NULL,
  `flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '排序标识',
  PRIMARY KEY (`impeachid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='意见反馈表';

-- ----------------------------
-- Records of zls_web_impeach
-- ----------------------------

-- ----------------------------
-- Table structure for zls_web_itemcatch
-- ----------------------------
DROP TABLE IF EXISTS `zls_web_itemcatch`;
CREATE TABLE `zls_web_itemcatch` (
  `itemcatchid` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `itemcatchname` varchar(64) NOT NULL COMMENT '名称标示',
  `setid` int(11) NOT NULL COMMENT '对象id',
  `detail` varchar(1000) NOT NULL COMMENT '网址',
  `rule` text COMMENT '抓取规则',
  `active` tinyint(4) NOT NULL DEFAULT '1' COMMENT '启用激活',
  `flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`itemcatchid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='抓取设置表';

-- ----------------------------
-- Records of zls_web_itemcatch
-- ----------------------------

-- ----------------------------
-- Table structure for zls_web_itemset
-- ----------------------------
DROP TABLE IF EXISTS `zls_web_itemset`;
CREATE TABLE `zls_web_itemset` (
  `setid` tinyint(4) unsigned NOT NULL AUTO_INCREMENT,
  `setname` varchar(255) NOT NULL COMMENT '对象名称',
  `setmultitable` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '分离大字段',
  `setennametable` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '表名是否使用英文',
  `setsetid` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否有相关对象',
  `setobject` varchar(255) DEFAULT NULL COMMENT '相关子对象ID，编辑时显示',
  `setlistsetid` tinyint(1) NOT NULL DEFAULT '0' COMMENT '相关子对象列表显示',
  `setlistobject` varchar(255) DEFAULT NULL COMMENT '设置列表显示关联子对象ID',
  `setpid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有相关父对象',
  `setlistpid` tinyint(1) NOT NULL DEFAULT '0' COMMENT '列表时是否有父对象',
  `seteditclass` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否需要自带分类',
  `setchannel` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '频道',
  `setsort` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '辅助分类',
  `setposttime` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否数据生成时间',
  `setactive` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否需要数据激活',
  `setflag` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否需要排序',
  `setuserid` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否需要数据用户权限',
  `setloginuser` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '生成登录用户',
  `setgroupid` tinyint(1) unsigned NOT NULL COMMENT '数据角色权限',
  `settag` tinyint(1) NOT NULL DEFAULT '0' COMMENT '标签(关键字)',
  `setclass` varchar(5000) NOT NULL COMMENT '具体分类项',
  `setexcel` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '显示生成excel',
  `setenname` varchar(255) DEFAULT NULL COMMENT '英文名称',
  `settype` text NOT NULL COMMENT '字段json',
  `sethtml` varchar(10) DEFAULT NULL COMMENT '关联静态化规则:',
  `sethtmlget` varchar(300) DEFAULT NULL COMMENT '关联静态化规则GET参数替换规则',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否激活',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '类型',
  `flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '排序',
  `img` varchar(80) DEFAULT NULL COMMENT '图片',
  `subject` char(80) DEFAULT NULL COMMENT '名称',
  `testime` tinyint(4) unsigned DEFAULT NULL COMMENT 'nihao',
  `height` varchar(2000) DEFAULT NULL COMMENT '测试',
  `medit_5` tinyint(4) unsigned DEFAULT NULL COMMENT '多级级联',
  `code` varchar(2000) DEFAULT NULL COMMENT '代码示例',
  PRIMARY KEY (`setid`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='对象设置表';

-- ----------------------------
-- Records of zls_web_itemset
-- ----------------------------
INSERT INTO `zls_web_itemset` VALUES ('1', '系统后台菜单', '0', '1', '0', null, '0', null, '0', '0', '0', '0', '0', '0', '1', '1', '0', '0', '0', '0', '{\"0\": { \"v\": \"0\",\"k\": \"默认\",\"s\": \"1\"}}', '0', 'menu', '{\"1\": { \"v\": \"\",\"type\":\"text\",\"id\":\"1\",\"d\":\"菜单名称\",\"note\":\"\",\"f\":\"subject\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"1\",\"sw\":\"1\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"2\": { \"v\": \"\",\"type\":\"text\",\"id\":\"2\",\"d\":\"后台文件名\",\"note\":\"\",\"f\":\"action\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"1\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"3\": { \"v\": \"\",\"type\":\"text\",\"id\":\"4\",\"d\":\"数据表中间部分\",\"note\":\"\",\"f\":\"pertable\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"1\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"4\": { \"v\": \"\",\"type\":\"text\",\"id\":\"3\",\"d\":\"数据表后缀/操作\",\"note\":\"\",\"f\":\"operation\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"1\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"5\": { \"v\": \"&\",\"type\":\"text\",\"id\":\"5\",\"d\":\"链接其他部分\",\"note\":\"\",\"f\":\"other\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"1\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"6\": { \"v\": \"0\",\"type\":\"mediumint\",\"id\":\"6\",\"d\":\"上级菜单\",\"note\":\"\",\"f\":\"edit_1\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"1\",\"sw\":\"1\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"7\": { \"v\": \"\",\"type\":\"text\",\"id\":\"7\",\"d\":\"标示ico\",\"note\":\"\",\"f\":\"ico\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"}}', '0', null, '0', '1', '120', null, null, null, null, null, null);
INSERT INTO `zls_web_itemset` VALUES ('2', '科目', '0', '1', '0', '', '0', '', '0', '0', '0', '0', '0', '0', '0', '1', '0', '0', '0', '0', '{\"0\": { \"v\": \"0\",\"k\": \"默认\",\"s\": \"1\"}}', '0', 'subject', '{\"1\": { \"v\": \"\",\"type\":\"text\",\"id\":\"3\",\"d\":\"年级\",\"note\":\"\",\"f\":\"edit_grade\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"2\": { \"v\": \"\",\"type\":\"text\",\"id\":\"2\",\"d\":\"科目名称\",\"note\":\"科目名称\",\"f\":\"subject\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"}}', '', '', '0', '0', '0', null, null, null, null, null, null);
INSERT INTO `zls_web_itemset` VALUES ('3', '地区', '0', '1', '0', '', '0', '', '0', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '{\"0\": { \"v\": \"0\",\"k\": \"默认\",\"s\": \"1\"}}', '0', 'area', '{\"1\": { \"v\": \"\",\"type\":\"text\",\"id\":\"1\",\"d\":\"地区名称\",\"note\":\"地区名称\",\"f\":\"area_name\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"1\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"}}', '', '', '0', '0', '0', null, null, null, null, null, null);
INSERT INTO `zls_web_itemset` VALUES ('4', '省份', '0', '1', '0', '', '1', '3', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '{\"0\": { \"v\": \"0\",\"k\": \"默认\",\"s\": \"1\"}}', '0', 'province', '{\"1\": { \"v\": \"\",\"type\":\"text\",\"id\":\"1\",\"d\":\"省份名称\",\"note\":\"\",\"f\":\"province_name\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"1\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"}}', '', '', '0', '0', '0', null, null, null, null, null, null);
INSERT INTO `zls_web_itemset` VALUES ('5', '年级', '0', '1', '0', '', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '{\"0\": { \"v\": \"0\",\"k\": \"默认\",\"s\": \"1\"}}', '0', 'grade', '{\"1\": { \"v\": \"\",\"type\":\"text\",\"id\":\"1\",\"d\":\"年级名称\",\"note\":\"\",\"f\":\"subject\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"1\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"}}', '', '', '0', '0', '0', null, null, null, null, null, null);
INSERT INTO `zls_web_itemset` VALUES ('6', '学历', '0', '1', '0', '', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '{\"0\": { \"v\": \"0\",\"k\": \"默认\",\"s\": \"1\"}}', '0', 'education', '{\"1\": { \"v\": \"\",\"type\":\"text\",\"id\":\"1\",\"d\":\"学历\",\"note\":\"\",\"f\":\"subject\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"1\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"}}', '', '', '0', '0', '0', null, null, null, null, null, null);
INSERT INTO `zls_web_itemset` VALUES ('8', '教学经历', '0', '1', '0', '', '0', '', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '{\"0\": { \"v\": \"0\",\"k\": \"默认\",\"s\": \"1\"}}', '0', 'teacher_experience', '{\"1\": { \"v\": \"\",\"type\":\"date\",\"id\":\"1\",\"d\":\"这里写说明\",\"note\":\"\",\"f\":\"begin\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"1\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"2\": { \"v\": \"\",\"type\":\"date\",\"id\":\"2\",\"d\":\"这里写说明\",\"note\":\"\",\"f\":\"end\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"1\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"3\": { \"v\": \"\",\"type\":\"text\",\"id\":\"3\",\"d\":\"所教学校\",\"note\":\"\",\"f\":\"school\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"1\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"4\": { \"v\": \"\",\"type\":\"text\",\"id\":\"4\",\"d\":\"授课科目\",\"note\":\"\",\"f\":\"subject\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"1\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"5\": { \"v\": \"\",\"type\":\"textarea\",\"id\":\"5\",\"d\":\"教学内容\",\"note\":\"\",\"f\":\"content\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"}}', '', '', '0', '0', '0', null, null, null, null, null, null);
INSERT INTO `zls_web_itemset` VALUES ('9', '老师毕业院校', '0', '1', '0', '', '0', '', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '{\"0\": { \"v\": \"0\",\"k\": \"默认\",\"s\": \"1\"}}', '0', 'teacher_university', '{\"1\": { \"v\": \"\",\"type\":\"text\",\"id\":\"1\",\"d\":\"毕业院校全称\",\"note\":\"\",\"f\":\"university\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"2\": { \"v\": \"\",\"type\":\"date\",\"id\":\"2\",\"d\":\"入学时间\",\"note\":\"\",\"f\":\"enrol\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"3\": { \"v\": \"\",\"type\":\"date\",\"id\":\"3\",\"d\":\"毕业时间\",\"note\":\"\",\"f\":\"graduation\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"4\": { \"v\": \"\",\"type\":\"text\",\"id\":\"4\",\"d\":\"学习专业\",\"note\":\"\",\"f\":\"major\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"5\": { \"0\": { \"v\": \"大专\",\"k\": \"大专\",\"s\": \"1\"},\"1\": { \"v\": \"本科\",\"k\": \"本科\",\"s\": \"0\"},\"2\": { \"v\": \"研究生\",\"k\": \"研究生\",\"s\": \"0\"},\"3\": { \"v\": \"博士\",\"k\": \"博士\",\"s\": \"0\"},\"4\": { \"v\": \"博士后\",\"k\": \"博士后\",\"s\": \"0\"},\"type\":\"select\",\"id\":\"5\",\"d\":\"学校学历\",\"note\":\"\",\"f\":\"education\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"}}', '', '', '0', '0', '0', null, null, null, null, null, null);
INSERT INTO `zls_web_itemset` VALUES ('10', '老师', '0', '1', '1', '9,8,11', '1', '12,15', '0', '0', '0', '0', '0', '1', '1', '1', '1', '1', '0', '0', '{\"0\": { \"v\": \"0\",\"k\": \"默认\",\"s\": \"1\"}}', '0', 'teacher', '{\"1\": { \"v\": \"\",\"type\":\"text\",\"id\":\"1\",\"d\":\"老师姓名\",\"note\":\"\",\"f\":\"teacher\",\"lw\":\"1\",\"ll\":\"60\",\"le\":\"0\",\"sw\":\"1\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"2\": { \"v\": \"\",\"type\":\"file\",\"id\":\"2\",\"d\":\"真实头像\",\"note\":\"\",\"f\":\"avatar\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"3\": { \"0\": { \"v\": \"男\",\"k\": \"男\",\"s\": \"0\"},\"1\": { \"v\": \"女\",\"k\": \"女\",\"s\": \"0\"},\"2\": { \"v\": \"保密\",\"k\": \"保密\",\"s\": \"0\"},\"type\":\"radio\",\"id\":\"3\",\"d\":\"性别\",\"note\":\"\",\"f\":\"gender\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"1\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"4\": { \"0\": { \"v\": \"5年以下\",\"k\": \"5年以下\",\"s\": \"1\"},\"1\": { \"v\": \"5年到10年\",\"k\": \"5年-10年\",\"s\": \"0\"},\"2\": { \"v\": \"10年以上\",\"k\": \"10年以上\",\"s\": \"0\"},\"type\":\"select\",\"id\":\"4\",\"d\":\"教学经验\",\"note\":\"\",\"f\":\"experience\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"1\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"5\": { \"v\": \"\",\"type\":\"text\",\"id\":\"5\",\"d\":\"常住地址\",\"note\":\"\",\"f\":\"address\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"6\": { \"0\": { \"v\": \"大专\",\"k\": \"大专\",\"s\": \"1\"},\"1\": { \"v\": \"本科\",\"k\": \"本科\",\"s\": \"0\"},\"2\": { \"v\": \"研究生\",\"k\": \"研究生\",\"s\": \"0\"},\"3\": { \"v\": \"博士\",\"k\": \"博士\",\"s\": \"0\"},\"type\":\"select\",\"id\":\"7\",\"d\":\"最高学历\",\"note\":\"\",\"f\":\"education\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"7\": { \"0\": { \"v\": \"小学\",\"k\": \"小学\",\"s\": \"0\"},\"1\": { \"v\": \"初中\",\"k\": \"初中\",\"s\": \"0\"},\"2\": { \"v\": \"高中\",\"k\": \"高中\",\"s\": \"0\"},\"type\":\"checkbox\",\"id\":\"8\",\"d\":\"可授年级\",\"note\":\"\",\"f\":\"grade\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"8\": { \"0\": { \"v\": \"数学\",\"k\": \"数学\",\"s\": \"0\"},\"1\": { \"v\": \"英语\",\"k\": \"英语\",\"s\": \"0\"},\"2\": { \"v\": \"语文\",\"k\": \"语文\",\"s\": \"0\"},\"3\": { \"v\": \"化学\",\"k\": \"化学\",\"s\": \"0\"},\"4\": { \"v\": \"地理\",\"k\": \"地理\",\"s\": \"0\"},\"5\": { \"v\": \"物理\",\"k\": \"物理\",\"s\": \"0\"},\"6\": { \"v\": \"历史\",\"k\": \"历史\",\"s\": \"0\"},\"type\":\"checkbox\",\"id\":\"9\",\"d\":\"可授科目\",\"note\":\"\",\"f\":\"taught\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"9\": { \"0\": { \"v\": \"专业教师\",\"k\": \"专业教师\",\"s\": \"0\"},\"1\": { \"v\": \"大学生/毕业生\",\"k\": \"大学生/毕业生\",\"s\": \"0\"},\"type\":\"radio\",\"id\":\"10\",\"d\":\"毕业状况\",\"note\":\"\",\"f\":\"graduation\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"10\": { \"0\": { \"v\": \"未认证\",\"k\": \"未认证\",\"s\": \"1\"},\"1\": { \"v\": \"已认证\",\"k\": \"已认证\",\"s\": \"0\"},\"type\":\"select\",\"id\":\"11\",\"d\":\"老师认证\",\"note\":\"\",\"f\":\"auth\",\"lw\":\"1\",\"ll\":\"50\",\"le\":\"1\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"11\": { \"v\": \"\",\"type\":\"text\",\"id\":\"12\",\"d\":\"微信\",\"note\":\"\",\"f\":\"wechat\",\"lw\":\"1\",\"ll\":\"80\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"12\": { \"v\": \"\",\"type\":\"text\",\"id\":\"13\",\"d\":\"手机\",\"note\":\"\",\"f\":\"mobile\",\"lw\":\"1\",\"ll\":\"80\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"13\": { \"v\": \"\",\"type\":\"text\",\"id\":\"14\",\"d\":\"价格\",\"note\":\"元\",\"f\":\"price\",\"lw\":\"1\",\"ll\":\"60\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"14\": { \"0\": { \"v\": \"45分钟\",\"k\": \"45分钟\",\"s\": \"0\"},\"1\": { \"v\": \"1小时\",\"k\": \"1小时\",\"s\": \"1\"},\"type\":\"radio\",\"id\":\"16\",\"d\":\"价格时长\",\"note\":\"\",\"f\":\"pricetime\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"15\": { \"v\": \"\",\"type\":\"textarea\",\"id\":\"15\",\"d\":\"教学特点\",\"note\":\"\",\"f\":\"style\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"16\": { \"v\": \"\",\"type\":\"text\",\"id\":\"17\",\"d\":\"所在纬度\",\"note\":\"\",\"f\":\"latitude\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"17\": { \"v\": \"\",\"type\":\"text\",\"id\":\"18\",\"d\":\"所在经度\",\"note\":\"\",\"f\":\"longitude\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"18\": { \"v\": \"0\",\"type\":\"single\",\"id\":\"19\",\"d\":\"评价分数\",\"note\":\"\",\"f\":\"score\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"19\": { \"v\": \"\",\"type\":\"text\",\"id\":\"20\",\"d\":\"城市\",\"note\":\"\",\"f\":\"city\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"20\": { \"v\": \"\",\"type\":\"text\",\"id\":\"21\",\"d\":\"地区\",\"note\":\"\",\"f\":\"area\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"21\": { \"v\": \"\",\"type\":\"date\",\"id\":\"25\",\"d\":\"生日\",\"note\":\"\",\"f\":\"birthday\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"22\": { \"v\": \"\",\"type\":\"datetime\",\"id\":\"22\",\"d\":\"最后登录时间\",\"note\":\"\",\"f\":\"lastlongin\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"23\": { \"v\": \"0\",\"type\":\"tinyint\",\"id\":\"23\",\"d\":\"注册流程状态\",\"note\":\"初始:0,老师1,学生2\",\"f\":\"myflag\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"24\": { \"v\": \"\",\"type\":\"text\",\"id\":\"24\",\"d\":\"微信openid\",\"note\":\"\",\"f\":\"openid\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"25\": { \"v\": \"\",\"type\":\"textarea\",\"id\":\"26\",\"d\":\"可授学科\",\"note\":\"大字段\",\"f\":\"gradetaught\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"26\": { \"v\": \"\",\"type\":\"text\",\"id\":\"27\",\"d\":\"可授时间\",\"note\":\"\",\"f\":\"teachtime\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"}}', '', '', '1', '0', '0', null, null, null, null, null, null);
INSERT INTO `zls_web_itemset` VALUES ('11', '老师相关证件', '0', '1', '0', '', '0', '', '1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '{\"0\": { \"v\": \"0\",\"k\": \"默认\",\"s\": \"1\"}}', '0', 'teacher_certificate', '{\"1\": { \"v\": \"\",\"type\":\"file\",\"id\":\"1\",\"d\":\"证件\",\"note\":\"\",\"f\":\"certificate\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"}}', '', '', '0', '0', '0', null, null, null, null, null, null);
INSERT INTO `zls_web_itemset` VALUES ('12', '评价老师', '0', '1', '0', '', '0', '', '0', '1', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '{\"0\": { \"v\": \"0\",\"k\": \"默认\",\"s\": \"1\"}}', '0', 'teacher_score', '{\"1\": { \"v\": \"\",\"type\":\"textarea\",\"id\":\"1\",\"d\":\"评价内容\",\"note\":\"\",\"f\":\"content\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"2\": { \"v\": \"0\",\"type\":\"single\",\"id\":\"3\",\"d\":\"评价分数\",\"note\":\"\",\"f\":\"score\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"3\": { \"v\": \"0\",\"type\":\"mediumint\",\"id\":\"6\",\"d\":\"评价者id\",\"note\":\"\",\"f\":\"fromuserid\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"4\": { \"v\": \"0\",\"type\":\"mediumint\",\"id\":\"7\",\"d\":\"关联的交易id\",\"note\":\"\",\"f\":\"statementid\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"}}', '', '', '0', '0', '0', null, null, null, null, null, null);
INSERT INTO `zls_web_itemset` VALUES ('13', '用户', '0', '1', '0', '', '0', '', '0', '0', '0', '0', '0', '0', '1', '1', '0', '0', '0', '0', '{\"0\": { \"v\": \"0\",\"k\": \"默认\",\"s\": \"1\"}}', '0', 'user', '{\"1\": { \"v\": \"\",\"type\":\"text\",\"id\":\"1\",\"d\":\"姓名\",\"note\":\"\",\"f\":\"username\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"2\": { \"v\": \"\",\"type\":\"text\",\"id\":\"2\",\"d\":\"密码\",\"note\":\"md5加密过的密码\",\"f\":\"userpass\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"3\": { \"v\": \"\",\"type\":\"text\",\"id\":\"3\",\"d\":\"昵称(唯一)\",\"note\":\"昵称(需要唯一)用作登录\",\"f\":\"nick\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"4\": { \"v\": \"\",\"type\":\"text\",\"id\":\"4\",\"d\":\"个性化域名\",\"note\":\"二级域名后缀(个性化域名例如www.wuseyun.com/wuseyun)\",\"f\":\"secname\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"5\": { \"v\": \"\",\"type\":\"text\",\"id\":\"5\",\"d\":\"登录邮箱\",\"note\":\"\",\"f\":\"email\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"6\": { \"v\": \"\",\"type\":\"text\",\"id\":\"6\",\"d\":\"登录手机\",\"note\":\"\",\"f\":\"mobile\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"7\": { \"v\": \"\",\"type\":\"text\",\"id\":\"7\",\"d\":\"头像\",\"note\":\"用户头像图网址\",\"f\":\"avatar\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"8\": { \"v\": \"0\",\"type\":\"tinyint\",\"id\":\"9\",\"d\":\"用户类型\",\"note\":\"用户类型即系统用户组，唯一对应的用户组\",\"f\":\"type\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"9\": { \"v\": \"\",\"type\":\"text\",\"id\":\"10\",\"d\":\"用户扩展组\",\"note\":\"用户所述用户组的扩展，用英文逗号分隔，可以是多个组合，例如：4,13,5，称之为角色\",\"f\":\"groupids\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"10\": { \"v\": \"\",\"type\":\"text\",\"id\":\"11\",\"d\":\"用户权限\",\"note\":\"优先级别最高,用户自身权限分配,对应的权限单元可以是多个组合,例如：4,13,5\",\"f\":\"usercells\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"}}', '', '', '1', '0', '0', null, null, null, null, null, null);
INSERT INTO `zls_web_itemset` VALUES ('14', '关注', '0', '1', '0', '', '0', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '{\"0\": { \"v\": \"0\",\"k\": \"默认\",\"s\": \"1\"}}', '0', 'teacher_follow', '{\"1\": { \"v\": \"0\",\"type\":\"mediumint\",\"id\":\"1\",\"d\":\"被关注者\",\"note\":\"\",\"f\":\"touserid\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"2\": { \"v\": \"0\",\"type\":\"mediumint\",\"id\":\"2\",\"d\":\"发起关注者\",\"note\":\"\",\"f\":\"fromuserid\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"}}', '', '', '1', '0', '0', null, null, null, null, null, null);
INSERT INTO `zls_web_itemset` VALUES ('15', '交易账单', '0', '1', '0', '', '0', '', '0', '1', '0', '0', '0', '1', '0', '0', '0', '0', '0', '0', '{\"0\": { \"v\": \"0\",\"k\": \"默认\",\"s\": \"1\"}}', '0', 'teacher_statement', '{\"1\": { \"v\": \"\",\"type\":\"text\",\"id\":\"4\",\"d\":\"服务内容\",\"note\":\"\",\"f\":\"subject\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"2\": { \"v\": \"0.00\",\"type\":\"decimal(20,2)\",\"id\":\"1\",\"d\":\"金额(元)\",\"note\":\"\",\"f\":\"amount\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"3\": { \"0\": { \"v\": \"0\",\"k\": \"未支付\",\"s\": \"1\"},\"1\": { \"v\": \"1\",\"k\": \"已支付\",\"s\": \"0\"},\"type\":\"radio\",\"id\":\"2\",\"d\":\"支付状态\",\"note\":\"0未支付，1已支付\",\"f\":\"status\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"4\": { \"0\": { \"v\": \"1\",\"k\": \"单次\",\"s\": \"0\"},\"1\": { \"v\": \"2\",\"k\": \"月度vip\",\"s\": \"0\"},\"2\": { \"v\": \"3\",\"k\": \"年度vip\",\"s\": \"0\"},\"type\":\"radio\",\"id\":\"3\",\"d\":\"付款类型\",\"note\":\"1单次，2月vip，3年vip\",\"f\":\"type\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"5\": { \"v\": \"0\",\"type\":\"mediumint\",\"id\":\"5\",\"d\":\"针对老师ID\",\"note\":\"\",\"f\":\"forteacher\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"6\": { \"v\": \"\",\"type\":\"datetime\",\"id\":\"6\",\"d\":\"vip起始时间\",\"note\":\"\",\"f\":\"start\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"7\": { \"v\": \"\",\"type\":\"datetime\",\"id\":\"7\",\"d\":\"vip终止时间\",\"note\":\"\",\"f\":\"end\",\"lw\":\"1\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"},\"8\": { \"0\": { \"v\": \"0\",\"k\": \"未评价\",\"s\": \"0\"},\"1\": { \"v\": \"1\",\"k\": \"已评价\",\"s\": \"0\"},\"type\":\"radio\",\"id\":\"8\",\"d\":\"评价\",\"note\":\"\",\"f\":\"score\",\"lw\":\"0\",\"ll\":\"100\",\"le\":\"0\",\"sw\":\"0\",\"mark\":\"0\",\"excel\":\"0\",\"ew\":\"1\"}}', '', '', '0', '0', '0', null, null, null, null, null, null);

-- ----------------------------
-- Table structure for zls_web_message
-- ----------------------------
DROP TABLE IF EXISTS `zls_web_message`;
CREATE TABLE `zls_web_message` (
  `messageid` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `messagename` varchar(255) NOT NULL COMMENT '您的姓名',
  `content` text COMMENT '留言内容',
  `comment` text COMMENT '回复留言',
  `posttime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '提交时间',
  `flag` tinyint(1) NOT NULL DEFAULT '0' COMMENT '排序',
  `active` tinyint(1) NOT NULL DEFAULT '0' COMMENT '有效留言',
  PRIMARY KEY (`messageid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='留言板';

-- ----------------------------
-- Records of zls_web_message
-- ----------------------------

-- ----------------------------
-- Table structure for zls_web_session
-- ----------------------------
DROP TABLE IF EXISTS `zls_web_session`;
CREATE TABLE `zls_web_session` (
  `sesskey` char(32) NOT NULL DEFAULT '' COMMENT 'sessionID标示',
  `expiry` int(10) NOT NULL DEFAULT '0' COMMENT '过期时间，过期即为不在线',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '用户ID',
  PRIMARY KEY (`userid`),
  KEY `expiry` (`expiry`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8 COMMENT='在线SESSION表';

-- ----------------------------
-- Records of zls_web_session
-- ----------------------------
INSERT INTO `zls_web_session` VALUES ('6ea615e787c59fc2af45352ded230fc2', '1552635651', '1977');

-- ----------------------------
-- Table structure for zls_web_sort
-- ----------------------------
DROP TABLE IF EXISTS `zls_web_sort`;
CREATE TABLE `zls_web_sort` (
  `sortid` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `sortname` varchar(30) NOT NULL COMMENT '辅助分类名称',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `type` smallint(6) NOT NULL DEFAULT '0' COMMENT '分类类型，0为用户定义，1为系统分类，...',
  `flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '排序',
  `active` tinyint(1) NOT NULL DEFAULT '1' COMMENT '激活与否',
  `click` smallint(5) unsigned NOT NULL COMMENT '点击量',
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  PRIMARY KEY (`sortid`),
  KEY `classname` (`sortname`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8 COMMENT='辅助分类表';

-- ----------------------------
-- Records of zls_web_sort
-- ----------------------------
INSERT INTO `zls_web_sort` VALUES ('1', '广告位置', '0', '1', '99', '1', '0', '0');
INSERT INTO `zls_web_sort` VALUES ('5', '替换词分类', '0', '1', '99', '1', '0', '0');
INSERT INTO `zls_web_sort` VALUES ('6', '敏感词', '0', '1', '0', '1', '0', '5');
INSERT INTO `zls_web_sort` VALUES ('33', '右侧下部广告', '0', '1', '0', '1', '0', '82');
INSERT INTO `zls_web_sort` VALUES ('34', '交流问答', '0', '1', '97', '1', '0', '0');
INSERT INTO `zls_web_sort` VALUES ('35', '模版标签', '0', '1', '0', '1', '0', '34');
INSERT INTO `zls_web_sort` VALUES ('36', 'CMS', '0', '1', '0', '1', '0', '34');
INSERT INTO `zls_web_sort` VALUES ('37', '注册', '0', '1', '0', '1', '0', '34');
INSERT INTO `zls_web_sort` VALUES ('38', '密码', '0', '1', '0', '1', '0', '34');
INSERT INTO `zls_web_sort` VALUES ('39', '登陆', '0', '1', '0', '1', '0', '34');
INSERT INTO `zls_web_sort` VALUES ('40', '抓取原创', '0', '1', '0', '1', '0', '5');
INSERT INTO `zls_web_sort` VALUES ('41', '测试词汇', '0', '1', '0', '1', '0', '5');
INSERT INTO `zls_web_sort` VALUES ('42', '简体转繁体', '0', '1', '0', '1', '0', '5');
INSERT INTO `zls_web_sort` VALUES ('43', 'CMS辅助分类', '0', '1', '97', '1', '0', '0');
INSERT INTO `zls_web_sort` VALUES ('44', '原创', '0', '1', '0', '1', '0', '43');
INSERT INTO `zls_web_sort` VALUES ('45', '转帖', '0', '1', '0', '1', '0', '43');
INSERT INTO `zls_web_sort` VALUES ('82', 'CMS信息类广告位置', '0', '1', '0', '1', '0', '1');
INSERT INTO `zls_web_sort` VALUES ('86', '上部轮显图', '0', '1', '0', '1', '0', '82');
INSERT INTO `zls_web_sort` VALUES ('87', '右侧上面广告位', '0', '1', '0', '1', '0', '82');
INSERT INTO `zls_web_sort` VALUES ('88', '右侧中部广告', '0', '1', '0', '1', '0', '82');
INSERT INTO `zls_web_sort` VALUES ('94', '程序错误', '0', '1', '0', '1', '0', '34');
INSERT INTO `zls_web_sort` VALUES ('95', '交流问答', '0', '1', '0', '1', '0', '34');
INSERT INTO `zls_web_sort` VALUES ('96', '用户中心', '0', '1', '0', '1', '0', '34');
INSERT INTO `zls_web_sort` VALUES ('97', '投票', '0', '1', '0', '1', '0', '34');
INSERT INTO `zls_web_sort` VALUES ('98', '不良信息', '0', '1', '0', '1', '0', '34');
INSERT INTO `zls_web_sort` VALUES ('99', '运营', '0', '1', '0', '1', '0', '34');
INSERT INTO `zls_web_sort` VALUES ('105', '其他', '0', '1', '0', '1', '0', '34');
INSERT INTO `zls_web_sort` VALUES ('106', '浮动在线客服联系方式', '0', '1', '99', '1', '0', '0');
INSERT INTO `zls_web_sort` VALUES ('107', 'QQ在线客服', '0', '1', '0', '1', '0', '106');
INSERT INTO `zls_web_sort` VALUES ('108', '电话在线客服', '0', '1', '0', '1', '0', '106');
INSERT INTO `zls_web_sort` VALUES ('109', 'Email在线客服', '0', '1', '0', '1', '0', '106');
INSERT INTO `zls_web_sort` VALUES ('110', '首页中间轮番图幻灯片', '0', '1', '0', '1', '0', '1');
INSERT INTO `zls_web_sort` VALUES ('111', '国内公司', '0', '1', '0', '1', '0', '43');
INSERT INTO `zls_web_sort` VALUES ('112', '国外公司', '0', '1', '0', '1', '0', '43');
INSERT INTO `zls_web_sort` VALUES ('113', '国内资讯', '0', '1', '0', '1', '0', '43');
INSERT INTO `zls_web_sort` VALUES ('114', '国外资讯', '0', '1', '0', '1', '0', '43');
INSERT INTO `zls_web_sort` VALUES ('115', '生活', '0', '1', '0', '1', '0', '43');
INSERT INTO `zls_web_sort` VALUES ('116', '专栏', '0', '1', '0', '1', '0', '43');
INSERT INTO `zls_web_sort` VALUES ('117', '网站欣赏', '0', '1', '0', '1', '0', '43');

-- ----------------------------
-- Table structure for zls_web_tag
-- ----------------------------
DROP TABLE IF EXISTS `zls_web_tag`;
CREATE TABLE `zls_web_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemid` mediumint(8) unsigned NOT NULL DEFAULT '0' COMMENT '数据id',
  `tagname` char(30) NOT NULL COMMENT '标签名称',
  `setid` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '标签类型，0为用户定义，正整数数字id为对象id',
  `channelid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '频道id',
  `sortid` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '辅助分类id',
  `open` tinyint(1) DEFAULT '2' COMMENT '是否开放；1开放；2关闭',
  PRIMARY KEY (`id`),
  KEY `setid` (`setid`),
  KEY `itemid` (`itemid`),
  KEY `tagname` (`tagname`),
  KEY `channelid` (`channelid`),
  KEY `sortid` (`sortid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='系统标签表';

-- ----------------------------
-- Records of zls_web_tag
-- ----------------------------
